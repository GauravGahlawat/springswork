package com.niit.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.Service.BankService;

public class BankClient {

	public static void main(String[] args) {
		

		ApplicationContext context = new ClassPathXmlApplicationContext("bank.xml");
		BankService bank = (BankService)context.getBean(BankService.class);
		bank.deposit("testing");
	}

}
