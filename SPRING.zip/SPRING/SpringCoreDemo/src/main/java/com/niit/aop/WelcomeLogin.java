package com.niit.aop;

import java.util.Date;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component // marks java class as Bean
@Aspect
public class WelcomeLogin {
	
	@Before("execution(* com.niit.Service.*.*(..))")  //pointcut in before advice
	public void logBefore()
	{
		System.out.println("*****************WELCOME TO ICICI BANK****************");
	}
	@After("execution(* com.niit.Service.*.*(..))")
	public void logAfter()
	{
		System.out.println("***************THANK YOU VIST AGAIN*****************");
	}
	

}
