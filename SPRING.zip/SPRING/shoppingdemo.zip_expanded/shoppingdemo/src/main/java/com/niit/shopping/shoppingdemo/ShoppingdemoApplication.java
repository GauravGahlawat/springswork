package com.niit.shopping.shoppingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingdemoApplication.class, args);
	}

}
