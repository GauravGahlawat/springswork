package snippet;

public class Snippet {
	
	ApplicationContext context = new ClassPathXmlApplicationContext("account.xml");
	UserAccountService uas ;
}

