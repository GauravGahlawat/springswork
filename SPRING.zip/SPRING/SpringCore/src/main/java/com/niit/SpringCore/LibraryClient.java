package com.niit.SpringCore;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryClient {

	public static void main(String[] args) {


		ApplicationContext context = new ClassPathXmlApplicationContext("book.xml");
		Library library = (Library) context.getBean("library");

		// List Of Books
		List booklist = library.getBookList();
		//let's print the properties of the Book
		for(int i=0;i<booklist.size();i++)
		{
			System.out.println("** Book" + (i+1) + " Properties **");
			Book book = (Book) booklist.get(i);
			System.out.println("Book Tile :" +book.getTitle());
			System.out.println("Book Author :" + book.getAuthor());
			System.out.println("Book Publications :" + book.getPublications());
		}
		
		//let's print the primitives
		List stringList = library.getStringList();
		System.out.println("Primitives set to List :" + stringList);

	}

}
