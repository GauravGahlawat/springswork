package com.niit.myproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.myproject.dao.UserDao;
import com.niit.myproject.model.User;

@Controller
@ComponentScan("com.niit.myproject")
/* @RestController */
public class SpringBootJdbcController {
	
	@Autowired
	JdbcTemplate jdbc;
	@Autowired
	UserDao dao;
	
	@RequestMapping("/insert")
	public String inputdata()
	{
		jdbc.execute("insert into user(name,email)values('gaurav','gauravgahlawat1997@gmail.com')");
		return "Data Inserted Successfully";
	}
	

	@RequestMapping("/update")
	public String inputdata1()
	{
		jdbc.execute("update user set name='candy' where id=1");
		return "Data Updated Successfully";
	}
	

	@RequestMapping("/delete")
	public String inputdata2()
	{
		jdbc.execute("delete from user where id=1");
		return "Data Deleted Successfully";
	}
	
	/*
	 * @RequestMapping("/viewuser") public String viewUsers(Model m) { List <User>
	 * list =dao.getUsers(); m.addAttribute("list",list); return "viewuser"; }
	 */
	
	//value="/list-todos", method = RequestMethod.GET
		@RequestMapping(value="/viewuser", method = RequestMethod.GET)
		public String viewUsers(Model m)
		{
			//jdbc.execute("select * from user");
			List<User> list=dao.getUsers();
			System.out.println(list.toString());
			m.addAttribute("users",list);
			
					return "userList";
		}

}
